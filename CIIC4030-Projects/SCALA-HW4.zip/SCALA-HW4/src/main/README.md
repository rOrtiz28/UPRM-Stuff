# En esta asignacion se buscaba disminuir el ruido de una foto.

La tecnica que se utilizo fue "median filter" para disminuir el ruido de la foto enviada por el usuario.

Ademas se uso una aplicacion servidor / cliente para procesar las imagenes en Scala.

Se aceptaba una foto en el formato "jpg" (test.jpg) para luego ser somatida a un servidor en paralelo y otro serial. En estos servidores se procesaban los pixeles con mayor numero de repeticiones para asi retirar el ruido.

Al terminar el programa se devuelven dos fotos re-creada de la original (HW4-TestPhoto.jpg) al usuario.

***Es importante que la foto que sera sometida se llame "HW4-TestPhoto.jpg"***

El programa se ejecuta con el comando en el terminal: 
>> sbt run