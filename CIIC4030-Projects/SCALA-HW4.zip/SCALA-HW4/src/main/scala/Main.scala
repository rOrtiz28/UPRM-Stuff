import java.io.File
import akka.actor._
import scala.collection.mutable.ListBuffer
import scala.language.postfixOps
import akka.event.{Logging, LoggingAdapter}
import javax.imageio.ImageIO
import java.awt.image.BufferedImage
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration.DurationInt
import scala.concurrent.{Await, ExecutionContext, ExecutionContextExecutor, Future}

object Main extends App {
  var photoPath = new File("./src/main/images/HW4-TestPhoto.jpg")
  val system = ActorSystem("ActorSystem")
  var server = system.actorOf(Props[Server],"Server")
  println(photoPath.getAbsolutePath)
  server ! photoPath
  system.terminate()
}