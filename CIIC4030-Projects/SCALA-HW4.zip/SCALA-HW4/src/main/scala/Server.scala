import java.io.File
import akka.actor._
import scala.collection.mutable.ListBuffer
import scala.language.postfixOps
import akka.event.{Logging, LoggingAdapter}
import javax.imageio.ImageIO
import java.awt.image.BufferedImage
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration.DurationInt
import scala.concurrent.{Await, ExecutionContext, ExecutionContextExecutor, Future}

class Server extends Actor {
  var height, width = 3
  var serialActor: ActorRef = context.actorOf(Props(new serialServer(width, height)),"Serial_Filter_Actor")
  var parallelActor: ActorRef = context.actorOf(Props(new parallelServer(width, height)),"Parallel_Filter_Actor")
  val log: LoggingAdapter = Logging(context.system, this)

  def receive: Receive = {
    case path:File =>
      val image = ImageIO.read(path)
      println("Image Received")
      implicit val timeout: Timeout = Timeout(100 seconds)
      val serialFuture: Future[Any] = ask(serialActor, image)
      val parallelFuture: Future[Any] = ask(parallelActor, image)
      val serialResult: BufferedImage = Await.result(serialFuture, 100 second).asInstanceOf[BufferedImage]
      val parallelResult: BufferedImage = Await.result(parallelFuture, 100 second).asInstanceOf[BufferedImage]

      val serial_Modified_Photo_path = new File(path.getParent + "/serial_Modified_Photo.jpg")
      val parallel_Modified_Photo_path = new File(path.getParent + "/parallel_Modified_Photo.jpg")
      ImageIO.write(serialResult, "jpg", serial_Modified_Photo_path)
      ImageIO.write(parallelResult, "jpg", parallel_Modified_Photo_path)
      println("Serial image as 'serial_Modified_Photo.jpg' at " + serial_Modified_Photo_path)
      println("Parallel image as 'parallel_Modified_Photo.jpg' at " + parallel_Modified_Photo_path)
    case _ => log.warning("Image was not received.")
  }
}