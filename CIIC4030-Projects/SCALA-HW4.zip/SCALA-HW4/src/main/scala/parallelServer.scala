import java.io.File
import akka.actor._
import scala.collection.mutable.ListBuffer
import scala.language.postfixOps
import akka.event.{Logging, LoggingAdapter}
import javax.imageio.ImageIO
import java.awt.image.BufferedImage
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration.DurationInt
import scala.concurrent.{Await, ExecutionContext, ExecutionContextExecutor, Future}



class parallelServer(var width:Int, var height:Int) extends Actor{
  val log: LoggingAdapter = Logging(context.system, this)

  override def receive: PartialFunction[Any, Unit] = {
    case image:BufferedImage =>
      println("Parallel Server received image successfully")
      val startTimeOfParallel = System.currentTimeMillis()
      val filteredImageOfParallel = this.parallelFilter(image)
      val endTimeOfParallel = System.currentTimeMillis() - startTimeOfParallel
      println("The parallel server execution time is "+ endTimeOfParallel + " milliseconds to filter the image.")
      sender() ! filteredImageOfParallel
  }

  def parallelFilter(inputImage: BufferedImage): BufferedImage = {
    val outputPixel = new BufferedImage(inputImage.getWidth(), inputImage.getHeight(), BufferedImage.TYPE_3BYTE_BGR)
    val edgeX = width / 2
    val edgeY = height / 2

    implicit val ec: ExecutionContextExecutor = ExecutionContext.global
    val futures = new ListBuffer[Future[Any]]

    for (x <- edgeX until inputImage.getWidth() - edgeX) {
      val otherFuture = Future {
        for (y <- edgeY until inputImage.getHeight() - edgeY) {
          val newFuture = Future {
            var i = 0
            val window = Array.fill(width * height)(0)
            for (x1 <- 0 until width) {
              for (y1 <- 0 until height) {
                window(i) = inputImage.getRGB(x + x1 - edgeX, y + y1 - edgeY)
                i += 1
              }
            }
            window.sortInPlace()
            outputPixel.setRGB(x, y, window(width * height / 2))
          }
          futures += newFuture
        }
      }
      futures += otherFuture
    }
    outputPixel
  }
}





