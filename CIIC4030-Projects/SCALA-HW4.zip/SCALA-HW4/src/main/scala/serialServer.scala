import java.io.File
import akka.actor._
import scala.collection.mutable.ListBuffer
import scala.language.postfixOps
import akka.event.{Logging, LoggingAdapter}
import javax.imageio.ImageIO
import java.awt.image.BufferedImage
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration.DurationInt
import scala.concurrent.{Await, ExecutionContext, ExecutionContextExecutor, Future}

class serialServer(var width:Int, var height:Int) extends Actor {
  val log: LoggingAdapter = Logging(context.system, this)

  def receive: PartialFunction[Any, Unit] = {
    case image:BufferedImage =>
      println("Serial Server received image successfully")
      val startTimeOfSerial = System.currentTimeMillis()
      val filteredImageOfSerial = this.serialFilter(image)
      val endTimeOfSerial = System.currentTimeMillis() - startTimeOfSerial
      println("The serial server execution time is "+ endTimeOfSerial + " milliseconds to filter the image.")
      sender() ! filteredImageOfSerial
  }

  def serialFilter(inputImage: BufferedImage): BufferedImage = {
    val outputPixel = new BufferedImage(inputImage.getWidth(), inputImage.getHeight(), BufferedImage.TYPE_3BYTE_BGR)
    val window = Array.fill(width*height)(0)
    val edgeX = width/2
    val edgeY = height/2

    for(x <- edgeX until inputImage.getWidth() - edgeX){
      for(y <- edgeY until inputImage.getHeight() - edgeY){
        var i = 0
        for ( x1 <- 0 until width ) {
          for ( y1 <- 0 until height ) {
            window(i) = inputImage.getRGB(x + x1 - edgeX, y + y1 - edgeY)
            i += 1
          }
        }
        window.sortInPlace()
        outputPixel.setRGB(x, y, window(width * height / 2))
      }
    }
    outputPixel
  }

}